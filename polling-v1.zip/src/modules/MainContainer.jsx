import React, { useState } from "react";
import "../stylesheets/MainContainer.css";

function Button(props) {
  return (
    <button className={props.class} onClick={props.onclick}>
      {props.msg}
    </button>
  );
}

function Option(props) {
  return <input placeholder="Enter the Option" />;
}

export const MainContainer = () => {
  const [unlock, setUnlock] = useState(true);
  const [isChatOpen, setChatOpen] = useState(false);
  const [isNewPoll, setNewPoll] = useState(false);

  function toggleUnlock() {
    setUnlock(!unlock);
  }

  function toggleChat() {
    setChatOpen(!isChatOpen);
  }

  function togglePoll() {
    console.log("a new poll is activated");
    setNewPoll(!isNewPoll);
  }

  function InitialDisplay() {
    return (
      <div className="container">
        <div className="btn-container">
          <Button onclick={toggleUnlock} msg="Unlock the Poll" />
          <Button onclick={togglePoll} msg="Add a Poll" />
        </div>
        <div className="chat-container">
          <Button onclick={toggleChat} msg="Chat with Us" />
          <ChatDisplay />
        </div>
      </div>
    );
  }

  function UnlockDisplay() {
    return (
      <div className="new-container">
        <Button onclick={toggleUnlock} msg="X" class="cancel-button" />
        <div className="form-container">
          <form action="">
            <div>
              <input type="text" placeholder="Username" />
            </div>
            <div>
              <input type="text" placeholder="Password" />
            </div>
            <Button msg="Let's Poll" />
          </form>
        </div>
        <div className="chat-container">
          <Button onclick={toggleChat} msg="Chat with Us" />
          <ChatDisplay />
        </div>
      </div>
    );
  }

  function NewPollDisplay() {
    return (
      <div className="new-container">
        <Button onclick={togglePoll} msg="X" class="cancel-button" />
        <div className="form-container">
          <form action="">
            <label htmlFor="">Enter a question</label>
            <input type="text" />
          </form>
        </div>
        <div className="option-container">
          <p>Add the options below</p>
          <Option />
          <Button onclick={addNewOption} msg="Add another Option" />
        </div>
        <div className="chat-container">
          <Button onclick={toggleChat} msg="Chat with Us" />
          <ChatDisplay />
        </div>
      </div>
    );
  }

  function addNewOption() {
    <Option />;
  }

  function ChatDisplay() {
    if (isChatOpen) {
      return (
        <div className="chat-disp-container">
          <Button onclick={toggleChat} msg="X" class="cancel-button" />I am a
          chatbox
        </div>
      );
    }
  }
  if (!isNewPoll) {
    return unlock ? <InitialDisplay /> : <UnlockDisplay />;
  }
  return isNewPoll ? <NewPollDisplay /> : <InitialDisplay />;
};
