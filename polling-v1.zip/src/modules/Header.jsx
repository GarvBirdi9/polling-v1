import React from "react";
import "../stylesheets/header.css";

export const Header = () => {
  return (
    <div className="flex">
      <div>Logo will be here</div>
      <div>user name will be here</div>
    </div>
  );
};
