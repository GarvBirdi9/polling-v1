import React, { useState } from "react";
import { Header } from "./Header";
import { MainContainer } from "./MainContainer";

export const Dashboard = () => {
  
  return (
    <div>
      <Header />
      <MainContainer />
    </div>
  );
};
