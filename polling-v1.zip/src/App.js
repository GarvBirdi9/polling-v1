
import "./App.css";
import { Dashboard } from "./modules/Dashboard";

const App = () => {
  return (
    <div>
      <Dashboard />
    </div>
  );
};

export default App;
